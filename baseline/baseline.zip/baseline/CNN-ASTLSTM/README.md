# CNN-ASTLSTM
Code for paper "An end-to-end neural network framework for SOH estimation and RUL prediction of lithium battery"

# Requirement
tensorflow==1.9.0
keras==2.1.5
hyperopt==0.1.2
