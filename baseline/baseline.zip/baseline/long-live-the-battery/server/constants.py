from os.path import join

NUM_SAMPLES = 6
MODEL_DIR = "saved_model/"
SAMPLES_DIR = join('static','samples')
