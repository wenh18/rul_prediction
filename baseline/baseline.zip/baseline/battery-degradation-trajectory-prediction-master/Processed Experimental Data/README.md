# P001
The processed data for 48 cells containing the important data extracted from both cycling ageing test and regular characterization tests.

# ipso
Basic ploting code

# Matlab code
Main ploting code for extracting the data from P001

# Contact
For the questions regarding the processed experimental data, please contact Philipp Dechent at philipp.dechent@isea.rwth-aachen.de.
