# IPSO

Matlab scripts for formatting plots

# Usage
Best use as git submodule