import pandas as pd
import pickle
from os.path import join
from sklearn.model_selection import GridSearchCV
import utils
import warnings
import train
import argparse

warnings.filterwarnings('ignore')


# current directory where .pkl files are present (for features extraction)
def parse_args():
    parser = argparse.ArgumentParser(description='Nature Energy 2019')
    parser.add_argument('--Data-DIR', type=str, default='../../dataset/nature/')
    parser.add_argument('--built-csv', action='store_true', default=True)
    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = parse_args()
    if not args.built_csv:
        # calling function to load from disk
        all_batches_dict = utils.load_batches_to_dict()
        # function to build features for ML
        features_df = utils.build_feature_df(all_batches_dict)

        # save all features 124 in disk in rebuild_features.csv file
        save_csv_path = join(args.Data_DIR, "rebuild_features.csv")
        features_df.to_csv(save_csv_path, index=False)
        print("Saved features to ", save_csv_path)

    # skip this cell if features are already build
    # read features from CSV file
    import pandas as pd

    features_df = pd.read_csv("./rebuild_features.csv")
    print("Full")
    features = utils.train_val_split(features_df, regression_type="full")
    train.regression(features, pca=False, normalize=False, n_components=3, alpha=0.0005,
                     l1_ratio=1, log_target=False, model="elastic")

    print("\nDischarge")
    features = utils.train_val_split(features_df, regression_type="discharge")
    train.regression(features, pca=False, normalize=False, n_components=3, alpha=0.0001,
                     l1_ratio=1, log_target=True, model="elastic")

    print("\nVariance")
    features = utils.train_val_split(features_df, regression_type="variance")
    train.regression(features, pca=False, normalize=False, n_components=3, alpha=0.001,
                     l1_ratio=1, log_target=True, model="elastic")

    print("Full")
    features_cls = utils.train_val_split(features_df, regression_type="full", model="classification")
    train.classification(features_cls, C=9, tol=0.01)

    print("\nVariance")
    features_cls = utils.train_val_split(features_df, regression_type="variance", model="classification")
    train.classification(features_cls, C=0.02, tol=0.001)

    print("\nDischarge")
    features_cls = utils.train_val_split(features_df, regression_type="discharge", model="classification")
    train.classification(features_cls, C=1, tol=0.1)
