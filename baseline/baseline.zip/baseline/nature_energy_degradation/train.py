from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.linear_model import ElasticNet
from sklearn.linear_model import Lasso
from sklearn import linear_model
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
import numpy as np

def regression(datasets, pca=False, normalize=True, log_target=True,
               n_components=5, alpha=1e-4, l1_ratio=0.99, model="elastic"):
    # get three sets
    x_train, y_train = datasets.get("train")
    x_val, y_val = datasets.get("val")
    x_test, y_test = datasets.get("test")

    if pca:
        # create pca object with n_components (n_components is the reduced feature dimension)
        _pca = PCA(n_components=n_components)
        _pca.fit(x_train)
        # transfrom data to reduced features
        x_train = _pca.transform(x_train)
        x_val = _pca.transform(x_val)
        x_test = _pca.transform(x_test)
    if normalize:
        # create normalization object to normalize data
        scaler = StandardScaler()
        # find normalization params from train set, (mean, std)
        scaler.fit(x_train)
        # normalize sets (0 mean, 1 std)
        x_train = scaler.transform(x_train)
        x_val = scaler.transform(x_val)
        x_test = scaler.transform(x_test)

    if model == "elastic":
        print("Elastic net")
        regr = ElasticNet(random_state=4, alpha=alpha, l1_ratio=l1_ratio)
    else:
        print("Lasso net")
        regr = Lasso(alpha=alpha)
    # labels/ targets might be converted to log version based on choice
    targets = np.log(y_train) if log_target else y_train
    # fit regression model
    regr.fit(x_train, targets)

    # predict values/cycle life for all three sets
    pred_train = regr.predict(x_train)
    pred_val = regr.predict(x_val)
    pred_test = regr.predict(x_test)

    if log_target:
        # scale up the preedictions
        pred_train, pred_val, pred_test = np.exp(pred_train), np.exp(pred_val), np.exp(pred_test)

    # mean percentage error (same as paper)
    error_train = mean_absolute_percentage_error(y_train, pred_train) * 100
    error_val = mean_absolute_percentage_error(y_val, pred_val) * 100
    error_test = mean_absolute_percentage_error(y_test, pred_test) * 100

    print(f"Regression Error batch 3 (test (secondary)):  {error_test}%")
    print(f"Regression Error (Train):, {error_train}%")
    print(f"Regression Error (validation (primary) test): {error_val}%")


def classification(datasets, pca=False, normalize=True,
                   n_components=5, C=1, tol=0.01):
    x_train, y_train = datasets.get("train")
    x_val, y_val = datasets.get("val")
    x_test, y_test = datasets.get("test")

    if pca:
        _pca = PCA(n_components=n_components)
        _pca.fit(x_train)
        x_train = _pca.transform(x_train)
        x_val = _pca.transform(x_val)
        x_test = _pca.transform(x_test)
    if normalize:
        scaler = StandardScaler()
        scaler.fit(x_train)
        x_train = scaler.transform(x_train)
        x_val = scaler.transform(x_val)
        x_test = scaler.transform(x_test)

    clf = LogisticRegression(penalty='l2', C=C, tol=tol, max_iter=1000)
    clf.fit(x_train, y_train)

    # Accuracy calculation
    acc_train = clf.score(x_train, y_train) * 100
    acc_val = clf.score(x_val, y_val) * 100
    acc_test = clf.score(x_test, y_test) * 100

    print(f"Accuracy batch 3 (test (secondary)):  {acc_test}%")
    print(f"Accuracy (Train):, {acc_train}%")
    print(f"Accuracy (validation (primary) test): {acc_val}%")
