# Implementation for data driven prediction of battery cycle life before capacity degradation
The code in this repository is unofficial implementation of  ['Data driven prediciton of battery cycle life before capacity degradation' by K.A. Severson, P.M. Attia, et al](https://www.nature.com/articles/s41560-019-0356-8)

matlab to .pkl is done using [https://data.matr.io/1/](https://data.matr.io/1/)

feature extraction is done using [https://github.com/dsr-18/long-live-the-battery]
